#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <vector>

class Appointment
{
	int year;
	int month;
	int day;
	int hour;
	int minute;
	bool isPM;
	std::string studentName;
	std::string professorName;
	std::string reasonForVisit;
public:
	Appointment(int year, int month, int day, int hour, int minute, bool isPM, std::string studentName, std::string professorName, std::string reasonForVisit)
	{
		this->year = year;
		this->month = month;
		this->day = day;
		this->hour = hour;
		this->hour = hour;
		this->hour = hour;
		this->minute = minute;
		this->isPM = isPM;
		this->studentName = studentName;
		this->professorName = professorName;
		this->reasonForVisit = reasonForVisit;
	}

	int getYear() { return year; }
	int getMonth() { return month; }
	int getDay() { return day; }
	int getHour() { return hour; }
	int getMinute() { return minute; }
	bool getIsPM() { return isPM; }
	std::string getStudentName() { return studentName; }
	std::string getProfessorName(){ return professorName; }
	std::string getReasonForVisit() { return reasonForVisit; }
};