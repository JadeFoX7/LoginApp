#pragma once
#include <ctime>
#include <chrono>
#include <iostream>
#include "Appointment.h"
#include <msclr\marshal_cppstd.h>

auto now = std::chrono::system_clock::now();
std::time_t now_c = std::chrono::system_clock::to_time_t(now);
struct tm *parts = std::localtime(&now_c);

std::vector<Appointment> Appointments;

namespace VisitorsLog {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			int numLines = -1;
			std::fstream counter;
			counter.open("VisitorsLog.txt");
			char c;
			while (!counter.eof())
			{
				counter.get(c);
				if (c == '\n') numLines++;
			}
			counter.close();
			int year = 0;
			int month = 0;
			int day = 0;
			int hour = 0;
			int minute = 0;
			bool isPM;
			std::string studentName;
			std::string professorName;
			std::string reasonForVisit;
			std::string temp;
			std::fstream log;
			log.open("VisitorsLog.txt"); // get log
		//	std::getline(log, temp, ',');
		//	year = std::stoi(temp);
		//	year = 5;
		//	log << year;
			
			for (int i = 0; i < numLines; i++)
			{
				std::getline(log, temp, ',');
				year = std::stoi(temp);
				std::getline(log, temp, ',');
				month = std::stoi(temp);
				std::getline(log, temp, ',');
				day = std::stoi(temp);
				std::getline(log, temp, ',');
				hour = std::stoi(temp);
				std::getline(log, temp, ',');
				minute = std::stoi(temp);
				std::getline(log, temp, ',');
				if (temp == "0") isPM = false;
				else			 isPM = true;
				std::getline(log, studentName, ',');
				std::getline(log, professorName, ',');
				std::getline(log, reasonForVisit, '\n');

				Appointments.push_back(Appointment(year, month, day, hour, minute, isPM, studentName, professorName, reasonForVisit));
			}
			
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			std::fstream log;
			log.open("VisitorsLog.txt");
			for (int i = 0; i < Appointments.size(); i++) {         // save log
				log << Appointments[i].getYear(); log << ',';
				log << Appointments[i].getMonth(); log << ',';
				log << Appointments[i].getDay(); log << ',';
				log << Appointments[i].getHour(); log << ',';
				log << Appointments[i].getMinute(); log << ',';
				if (Appointments[i].getIsPM()) { log << "1"; log << ','; }
				else						   { log << "0"; log << ","; }
				log << Appointments[i].getStudentName(); log << ',';
				log << Appointments[i].getProfessorName(); log << ',';
				log << Appointments[i].getReasonForVisit(); log << '\n';
			}

			log.close();

			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  visitorNameInput;
	protected:

	protected:
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Label^  date;
	private: System::Windows::Forms::Label^  time;
	private: System::Windows::Forms::Label^  visitorName;
	private: System::Windows::Forms::Label^  professorName;
	private: System::Windows::Forms::Label^  reasonForVisit;

	private: System::Windows::Forms::TextBox^  reasonInput;



	private: System::Windows::Forms::NumericUpDown^  minuteUpDown;
	private: System::Windows::Forms::ComboBox^  chooseAmPm;




	private: System::Windows::Forms::NumericUpDown^  hourUpDown;

	private: System::Windows::Forms::ListViewItem^ listViewItem1;
	private: System::Windows::Forms::Button^  submitButton;
	private: System::Windows::Forms::ListView^  listView1;
	private: System::Windows::Forms::ColumnHeader^  dateView;
	private: System::Windows::Forms::ColumnHeader^  timeView;
	private: System::Windows::Forms::ColumnHeader^  visitorView;
	private: System::Windows::Forms::ColumnHeader^  professorView;
	private: System::Windows::Forms::ColumnHeader^  reasonView;
	private: System::Windows::Forms::NumericUpDown^  yearUpDown;

	private: System::Windows::Forms::NumericUpDown^  dayUpDown;

	private: System::Windows::Forms::NumericUpDown^  monthUpDown;

	private: System::Windows::Forms::ListBox^  professorList;
	private: System::Windows::Forms::Button^  btnRemove;
private: System::Windows::Forms::Button^  button1;






	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->visitorNameInput = (gcnew System::Windows::Forms::TextBox());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->date = (gcnew System::Windows::Forms::Label());
			this->time = (gcnew System::Windows::Forms::Label());
			this->visitorName = (gcnew System::Windows::Forms::Label());
			this->professorName = (gcnew System::Windows::Forms::Label());
			this->reasonForVisit = (gcnew System::Windows::Forms::Label());
			this->reasonInput = (gcnew System::Windows::Forms::TextBox());
			this->minuteUpDown = (gcnew System::Windows::Forms::NumericUpDown());
			this->chooseAmPm = (gcnew System::Windows::Forms::ComboBox());
			this->hourUpDown = (gcnew System::Windows::Forms::NumericUpDown());
			this->submitButton = (gcnew System::Windows::Forms::Button());
			this->listView1 = (gcnew System::Windows::Forms::ListView());
			this->dateView = (gcnew System::Windows::Forms::ColumnHeader());
			this->timeView = (gcnew System::Windows::Forms::ColumnHeader());
			this->visitorView = (gcnew System::Windows::Forms::ColumnHeader());
			this->professorView = (gcnew System::Windows::Forms::ColumnHeader());
			this->reasonView = (gcnew System::Windows::Forms::ColumnHeader());
			this->yearUpDown = (gcnew System::Windows::Forms::NumericUpDown());
			this->dayUpDown = (gcnew System::Windows::Forms::NumericUpDown());
			this->monthUpDown = (gcnew System::Windows::Forms::NumericUpDown());
			this->professorList = (gcnew System::Windows::Forms::ListBox());
			this->btnRemove = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->minuteUpDown))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->hourUpDown))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->yearUpDown))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dayUpDown))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->monthUpDown))->BeginInit();
			this->SuspendLayout();
			// 
			// visitorNameInput
			// 
			this->visitorNameInput->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->visitorNameInput->Location = System::Drawing::Point(14, 350);
			this->visitorNameInput->Name = L"visitorNameInput";
			this->visitorNameInput->Size = System::Drawing::Size(225, 22);
			this->visitorNameInput->TabIndex = 0;
			this->visitorNameInput->TextChanged += gcnew System::EventHandler(this, &MyForm::visitorNameInput_TextChanged);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(35, 23);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(188, 195);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::CenterImage;
			this->pictureBox1->TabIndex = 1;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Click += gcnew System::EventHandler(this, &MyForm::pictureBox1_Click);
			// 
			// date
			// 
			this->date->AutoSize = true;
			this->date->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->date->Location = System::Drawing::Point(10, 234);
			this->date->Name = L"date";
			this->date->Size = System::Drawing::Size(42, 19);
			this->date->TabIndex = 2;
			this->date->Text = L"Date";
			// 
			// time
			// 
			this->time->AutoSize = true;
			this->time->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->time->Location = System::Drawing::Point(10, 282);
			this->time->Name = L"time";
			this->time->Size = System::Drawing::Size(43, 19);
			this->time->TabIndex = 3;
			this->time->Text = L"Time";
			// 
			// visitorName
			// 
			this->visitorName->AutoSize = true;
			this->visitorName->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->visitorName->Location = System::Drawing::Point(10, 328);
			this->visitorName->Name = L"visitorName";
			this->visitorName->Size = System::Drawing::Size(152, 19);
			this->visitorName->TabIndex = 4;
			this->visitorName->Text = L"Student/Visitor Name";
			// 
			// professorName
			// 
			this->professorName->AutoSize = true;
			this->professorName->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->professorName->Location = System::Drawing::Point(10, 375);
			this->professorName->Name = L"professorName";
			this->professorName->Size = System::Drawing::Size(129, 19);
			this->professorName->TabIndex = 5;
			this->professorName->Text = L"Professor/Advisor";
			// 
			// reasonForVisit
			// 
			this->reasonForVisit->AutoSize = true;
			this->reasonForVisit->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->reasonForVisit->Location = System::Drawing::Point(14, 456);
			this->reasonForVisit->Name = L"reasonForVisit";
			this->reasonForVisit->Size = System::Drawing::Size(154, 19);
			this->reasonForVisit->TabIndex = 6;
			this->reasonForVisit->Text = L"Reason For Your Visit";
			this->reasonForVisit->Click += gcnew System::EventHandler(this, &MyForm::reasonForVisit_Click);
			// 
			// reasonInput
			// 
			this->reasonInput->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->reasonInput->Location = System::Drawing::Point(13, 491);
			this->reasonInput->Name = L"reasonInput";
			this->reasonInput->Size = System::Drawing::Size(225, 22);
			this->reasonInput->TabIndex = 8;
			this->reasonInput->TextChanged += gcnew System::EventHandler(this, &MyForm::reasonInput_TextChanged);
			// 
			// minuteUpDown
			// 
			this->minuteUpDown->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->minuteUpDown->Location = System::Drawing::Point(85, 303);
			this->minuteUpDown->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 59, 0, 0, 0 });
			this->minuteUpDown->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->minuteUpDown->Name = L"minuteUpDown";
			this->minuteUpDown->Size = System::Drawing::Size(68, 22);
			this->minuteUpDown->TabIndex = 10;
			this->minuteUpDown->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { parts->tm_min, 0, 0, 0 });
			// 
			// chooseAmPm
			// 
			this->chooseAmPm->FormattingEnabled = true;
			this->chooseAmPm->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"AM", L"PM" });
			this->chooseAmPm->Location = System::Drawing::Point(159, 304);
			this->chooseAmPm->Name = L"chooseAmPm";
			this->chooseAmPm->Size = System::Drawing::Size(80, 21);
			this->chooseAmPm->TabIndex = 12;
			// 
			// hourUpDown
			// 
			this->hourUpDown->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->hourUpDown->Location = System::Drawing::Point(14, 303);
			this->hourUpDown->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 12, 0, 0, 0 });
			this->hourUpDown->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->hourUpDown->Name = L"hourUpDown";
			this->hourUpDown->Size = System::Drawing::Size(65, 22);
			this->hourUpDown->TabIndex = 14;
			this->hourUpDown->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { parts->tm_hour % 12, 0, 0, 0 });
			// 
			// submitButton
			// 
			this->submitButton->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->submitButton->Location = System::Drawing::Point(11, 528);
			this->submitButton->Name = L"submitButton";
			this->submitButton->Size = System::Drawing::Size(68, 47);
			this->submitButton->TabIndex = 15;
			this->submitButton->Text = L"Submit";
			this->submitButton->UseVisualStyleBackColor = true;
			this->submitButton->Click += gcnew System::EventHandler(this, &MyForm::submitButton_Click);
			// 
			// listView1
			// 
			this->listView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::ColumnHeader^  >(5) {
				this->dateView, this->timeView,
					this->visitorView, this->professorView, this->reasonView
			});
			this->listView1->Location = System::Drawing::Point(257, 12);
			this->listView1->Name = L"listView1";
			this->listView1->Size = System::Drawing::Size(790, 563);
			this->listView1->TabIndex = 16;
			this->listView1->UseCompatibleStateImageBehavior = false;
			this->listView1->View = System::Windows::Forms::View::Details;
			this->listView1->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::listView1_SelectedIndexChanged);
			// 
			// dateView
			// 
			this->dateView->Text = L"Date";
			this->dateView->Width = 86;
			// 
			// timeView
			// 
			this->timeView->Text = L"Time";
			this->timeView->Width = 91;
			// 
			// visitorView
			// 
			this->visitorView->Text = L"Student/Visitor Name";
			this->visitorView->Width = 181;
			// 
			// professorView
			// 
			this->professorView->Text = L"Professor/Advisor";
			this->professorView->Width = 196;
			// 
			// reasonView
			// 
			this->reasonView->Text = L"Reason For Your Visit";
			this->reasonView->Width = 199;
			// 
			// yearUpDown
			// 
			this->yearUpDown->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->yearUpDown->Location = System::Drawing::Point(159, 256);
			this->yearUpDown->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 3000, 0, 0, 0 });
			this->yearUpDown->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->yearUpDown->Name = L"yearUpDown";
			this->yearUpDown->Size = System::Drawing::Size(80, 22);
			this->yearUpDown->TabIndex = 17;
			this->yearUpDown->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { parts->tm_year + 1900, 0, 0, 0 });
			this->yearUpDown->ValueChanged += gcnew System::EventHandler(this, &MyForm::yearUpDown_ValueChanged);
			// 
			// dayUpDown
			// 
			this->dayUpDown->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->dayUpDown->Location = System::Drawing::Point(88, 256);
			this->dayUpDown->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 31, 0, 0, 0 });
			this->dayUpDown->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->dayUpDown->Name = L"dayUpDown";
			this->dayUpDown->Size = System::Drawing::Size(65, 22);
			this->dayUpDown->TabIndex = 18;
			this->dayUpDown->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { parts->tm_mday, 0, 0, 0 });
			// 
			// monthUpDown
			// 
			this->monthUpDown->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->monthUpDown->Location = System::Drawing::Point(15, 256);
			this->monthUpDown->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 12, 0, 0, 0 });
			this->monthUpDown->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 1, 0, 0, 0 });
			this->monthUpDown->Name = L"monthUpDown";
			this->monthUpDown->Size = System::Drawing::Size(65, 22);
			this->monthUpDown->TabIndex = 19;
			this->monthUpDown->Value = System::Decimal(gcnew cli::array< System::Int32 >(4) { parts->tm_mon + 1, 0, 0, 0 });
			// 
			// professorList
			// 
			this->professorList->FormattingEnabled = true;
			this->professorList->Items->AddRange(gcnew cli::array< System::Object^  >(10) {
				L"Corbin. Christopher", L"Lebron. David", L"Martinez. Juan Carlos",
					L"Massad. Nelson", L"Zejnilovic. Adnan", L"Auguste. Mylinda", L"Barake. Maria", L"Moscoso. Federico", L"Ramirez. Janet", L"Telfort. Roseline"
			});
			this->professorList->Location = System::Drawing::Point(14, 403);
			this->professorList->Name = L"professorList";
			this->professorList->Size = System::Drawing::Size(224, 43);
			this->professorList->TabIndex = 21;
			this->professorList->SelectedIndexChanged += gcnew System::EventHandler(this, &MyForm::professorList_SelectedIndexChanged);
			// 
			// btnRemove
			// 
			this->btnRemove->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnRemove->Location = System::Drawing::Point(85, 528);
			this->btnRemove->Name = L"btnRemove";
			this->btnRemove->Size = System::Drawing::Size(77, 47);
			this->btnRemove->TabIndex = 22;
			this->btnRemove->Text = L"Undo";
			this->btnRemove->UseVisualStyleBackColor = true;
			this->btnRemove->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Times New Roman", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(168, 528);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(68, 47);
			this->button1->TabIndex = 23;
			this->button1->Text = L"Load";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click_1);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1059, 587);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnRemove);
			this->Controls->Add(this->professorList);
			this->Controls->Add(this->monthUpDown);
			this->Controls->Add(this->dayUpDown);
			this->Controls->Add(this->yearUpDown);
			this->Controls->Add(this->listView1);
			this->Controls->Add(this->submitButton);
			this->Controls->Add(this->hourUpDown);
			this->Controls->Add(this->chooseAmPm);
			this->Controls->Add(this->minuteUpDown);
			this->Controls->Add(this->reasonInput);
			this->Controls->Add(this->reasonForVisit);
			this->Controls->Add(this->professorName);
			this->Controls->Add(this->visitorName);
			this->Controls->Add(this->time);
			this->Controls->Add(this->date);
			this->Controls->Add(this->visitorNameInput);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"MyForm";
			this->Text = L"Visitor\'s Log";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->minuteUpDown))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->hourUpDown))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->yearUpDown))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dayUpDown))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->monthUpDown))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dateTimePicker1_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
}
private: System::Void bindingSource1_CurrentChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void hourUpDown_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void listView1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void submitButton_Click(System::Object^  sender, System::EventArgs^  e) {
	int year = 0;
	int month = 0;
	int day = 0;
	int hour = 0;
	int minute = 0;
	bool isPM;
	std::string studentName;
	std::string professorName;
	std::string reasonForVisit;
	listViewItem1 = gcnew System::Windows::Forms::ListViewItem(this->monthUpDown->Text + "/" + this->dayUpDown->Text + "/" + this->yearUpDown->Text );
	listViewItem1->SubItems->Add(this->hourUpDown->Text + ":" + this->minuteUpDown->Text + " " + this->chooseAmPm->Text);
	listViewItem1->SubItems->Add(this->visitorNameInput->Text);
	listViewItem1->SubItems->Add(this->professorList->Text);
	listViewItem1->SubItems->Add(this->reasonInput->Text);
	//listView1->Items[0]->SubItems->Add(this->professorNameInput->Text); old
	//listView1->Items[2]->SubItems->Add(this->reasonInput->Text); old
	this->listView1->Items->Add(this->listViewItem1);
	year = Convert::ToInt16(yearUpDown->Text);
	month = Convert::ToInt16(monthUpDown->Text);
	day = Convert::ToInt16(dayUpDown->Text);
	hour = Convert::ToInt16(hourUpDown->Text);
	minute = Convert::ToInt16(minuteUpDown->Text);
	if (chooseAmPm->Text == L"PM") isPM = true;
	else                           isPM = false;

	studentName = msclr::interop::marshal_as<std::string>(visitorNameInput->Text);
	professorName = msclr::interop::marshal_as<std::string>(professorList->Text);
	reasonForVisit = msclr::interop::marshal_as<std::string>(reasonInput->Text);

	Appointments.push_back(Appointment(year, month, day, hour, minute, isPM, studentName, professorName, reasonForVisit));
}
private: System::Void visitorNameInput_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void professorList_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {

}
private: System::Void reasonInput_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void reasonForVisit_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	if (listView1->Items->Count > 0)
	this->listView1->Items->RemoveAt(listView1->Items->Count - 1);
	Appointments.erase(Appointments.end()-1);
}
private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {
	System::String ^ studentName;
	System::String ^ professorName;
	System::String ^ reasonForVisit;
	for (int i = 0; i < Appointments.size(); i++)
	{
		studentName = gcnew String(Appointments[i].getStudentName().c_str());
		professorName = gcnew String(Appointments[i].getProfessorName().c_str());
		reasonForVisit = gcnew String(Appointments[i].getReasonForVisit().c_str());

		listViewItem1 = gcnew System::Windows::Forms::ListViewItem(Appointments[i].getMonth() + "/" + Appointments[i].getDay() + "/" + Appointments[i].getYear());
		if (Appointments[i].getIsPM()) listViewItem1->SubItems->Add(Appointments[i].getHour() + ":" + Appointments[i].getMinute() + " " + "PM");
		else listViewItem1->SubItems->Add(Appointments[i].getHour() + ":" + Appointments[i].getMinute() + " " + "AM");
		listViewItem1->SubItems->Add(studentName);
		listViewItem1->SubItems->Add(professorName);
		listViewItem1->SubItems->Add(reasonForVisit);

		this->listView1->Items->Add(this->listViewItem1);
	}
}
private: System::Void yearUpDown_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
}
};
}
